const Joke = require('../models/Joke.model');

class JokesController {
    getAll(req, res)
    {
        Joke.find({})
            .then(jokes => res.json(jokes))
            .catch(err => res.json(err));
    }
    create(req, res) {
        let newJoke = new Joke(req.body);
        newJoke.save()
            .then(() => res.json({msg: "joke created"}))
            .catch(err => res.json(err));
            
    }
    getOne(req, res)
    {
        Joke.aggregate([
            {$sample: {size: 1}}
        ])
            .then(jokes => res.json(jokes))
            .catch(err => res.json(err));
    }

    deleteJoke(req, res) {
        Joke.remove({_id: "5e271ff529038a88dc49f410" })
            .then(() => res.json({msg: "joke deleted"}))
            .catch(err => res.json(err));
    }

    update(req, res) {

        Joke.update({setup: "why did the chicken cross the road?"}, {$set: {punchline: "this is the updated version"}})
            .then(() => res.json({msg: "joke updated"}))
            .catch(err => res.json(err));
    }
}

module.exports = new JokesController();