const Jokes = require('./controllers/Jokes.controller')

module.exports = app => {
    app.get("/api/jokes", Jokes.getAll)
    app.get("/api/jokes/getrandom", Jokes.getOne)
    app.post("/api/jokes/create", Jokes.create);
    app.delete("/api/jokes/delete", Jokes.deleteJoke);
    app.put("/api/jokes/update", Jokes.update);
}