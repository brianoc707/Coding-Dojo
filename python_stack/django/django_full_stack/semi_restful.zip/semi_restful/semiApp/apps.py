from django.apps import AppConfig


class SemiappConfig(AppConfig):
    name = 'semiApp'
