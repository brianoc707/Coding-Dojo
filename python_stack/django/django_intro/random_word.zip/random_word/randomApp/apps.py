from django.apps import AppConfig


class RandomappConfig(AppConfig):
    name = 'randomApp'
