from django.apps import AppConfig


class BooksauthorsappConfig(AppConfig):
    name = 'booksAuthorsApp'
