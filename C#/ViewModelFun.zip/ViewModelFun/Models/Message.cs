namespace ViewModelFun.Models
{
     public class Message
    {
        public string message {get;set;}
        
    }
    
}