namespace ViewModelFun.Models
{
public class Numbers
    {
        public int[] number {get;set;}
    }
}