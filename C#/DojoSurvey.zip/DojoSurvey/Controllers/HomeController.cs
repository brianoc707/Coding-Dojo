using Microsoft.AspNetCore.Mvc;
using System;
using DojoSurvey.Models;
namespace DojoSurvey
{
    public class HomeController : Controller
    {
        [HttpGet("")]
        
        public ViewResult Home()
        {
            
            
            return View();
        }
        
        [HttpPost("result")]
        public ViewResult Result(string Name, string Loc, string Lang, string Comment)
        {
            Survey newSurvey = new Survey()
            {
                Name = Name,
                Location = Loc,
                Language = Lang,
                Comment = Comment,

            };
             
            return View(newSurvey);
        }
       
    }
}